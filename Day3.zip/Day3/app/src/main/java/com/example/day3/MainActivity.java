package com.example.day3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final EditText x =  findViewById(R.id.height);
       final EditText y = findViewById(R.id.weight);
       Button cal = findViewById(R.id.button2);

       cal.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               //here we write what the button do هنا نكتب الداله
                // BMI = W/(h*h) *1000

               String heightString = x.getText().toString();//"166.6"
               String weightString = y.getText().toString();//"50"

              double height = Double.parseDouble(heightString);// 166.6
              double weight = Double.parseDouble(weightString); // 50

              double bmi =  (weight/ (height*height)) *10000 ;
              System.out.println(bmi);

               Toast.makeText(MainActivity.this,"this is your BMI: "+bmi,Toast.LENGTH_LONG).show();




           }
       });



    }
}